package edu.met.banking;

//unchecked exception can go unreported
public class IllegalTransferException extends RuntimeException {}

